//
//  FFmpeg.h
//  LiveDemo
//
//  Created by winter on 2020/5/12.
//  Copyright © 2020 Yeting. All rights reserved.
//

#ifndef FFmpeg_h
#define FFmpeg_h

// FFmpeg Header File
#ifdef __cplusplus
extern "C" {
#endif
    
#include "libavformat/avformat.h"
#include "libavcodec/avcodec.h"
#include "libavutil/avutil.h"
#include "libswscale/swscale.h"
#include "libswresample/swresample.h"
#include "libavutil/opt.h"
    
#ifdef __cplusplus
};
#endif

#endif /* FFmpeg_h */
